export const MAX_FREE_BOARDS = 5;
